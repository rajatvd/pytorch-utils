
A bunch of utilities for making training models easier. Also contains useful modules to make building models easier.
Designed to be used in a jupyter notebook workflow.


